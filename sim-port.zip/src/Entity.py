class Entity:

    def __init__(self, operationType):
        self.operationType = operationType

    def getOperationType(self):
        return self.operationType
